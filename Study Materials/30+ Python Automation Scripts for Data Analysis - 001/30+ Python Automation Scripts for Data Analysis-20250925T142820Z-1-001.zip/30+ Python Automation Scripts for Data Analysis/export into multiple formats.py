import pandas as pd

def export_data(df, filename, file_format="csv"):
    """
    Exports a DataFrame to CSV, JSON, or Excel.

    Args:
        df (pd.DataFrame): Data to export.
        filename (str): Name of the output file.
        file_format (str): Format ('csv', 'json', 'excel').

    Returns:
        None
    """
    if file_format == "csv":
        df.to_csv(f"{filename}.csv", index=False)
    elif file_format == "json":
        df.to_json(f"{filename}.json", orient="records", indent=4)
    elif file_format == "excel":
        df.to_excel(f"{filename}.xlsx", index=False)
    else:
        print("Unsupported format. Use 'csv', 'json', or 'excel'.")
    print(f"File saved as {filename}.{file_format}")

# Example usage
if __name__ == "__main__":
    data = {"Name": ["Alice", "Bob"], "Age": [25, 30]}
    df = pd.DataFrame(data)
    export_data(df, "output", "csv")  # Change "csv" to "json" or "excel" as needed
