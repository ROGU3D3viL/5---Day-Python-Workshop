import pandas as pd

def most_frequent_values(df):
    """
    Finds the most frequent value in each column.

    Args:
        df (pd.DataFrame): Input DataFrame.

    Returns:
        pd.Series: Most frequent values.
    """
    return df.mode().iloc[0]

# Example usage
if __name__ == "__main__":
    data = {"A": [1, 2, 2, 4], "B": ["Red", "Blue", "Blue", "Red"]}
    df = pd.DataFrame(data)
    print(most_frequent_values(df))
