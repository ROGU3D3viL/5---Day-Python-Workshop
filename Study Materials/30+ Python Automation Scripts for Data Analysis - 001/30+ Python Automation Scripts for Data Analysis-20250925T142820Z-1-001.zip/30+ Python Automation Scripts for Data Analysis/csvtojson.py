import pandas as pd

def csv_to_json(csv_file, json_file):
    """
    Converts a CSV file to JSON.

    Args:
        csv_file (str): Path to CSV file.
        json_file (str): Path to JSON file.

    Returns:
        None
    """
    df = pd.read_csv(csv_file)
    df.to_json(json_file, orient="records", indent=4)

# Example usage
if __name__ == "__main__":
    csv_to_json("data.csv", "data.json")
