import pandas as pd
from sklearn.preprocessing import LabelEncoder, OneHotEncoder

def encode_categorical(df, column, method='onehot'):
    """
    Encodes categorical columns using one-hot or label encoding.

    Args:
        df (pd.DataFrame): Input DataFrame.
        column (str): Column to encode.
        method (str): Encoding method ('onehot' or 'label').

    Returns:
        pd.DataFrame: DataFrame with encoded column.
    """
    if method == 'onehot':
        return pd.get_dummies(df, columns=[column])
    else:
        encoder = LabelEncoder()
        df[column] = encoder.fit_transform(df[column])
        return df

# Example usage
if __name__ == "__main__":
    data = {'Category': ['Red', 'Blue', 'Green', 'Blue']}
    df = pd.DataFrame(data)
    print("Before Encoding:\n", df)

    df = encode_categorical(df, 'Category', method='onehot')
    print("\nAfter Encoding:\n", df)
