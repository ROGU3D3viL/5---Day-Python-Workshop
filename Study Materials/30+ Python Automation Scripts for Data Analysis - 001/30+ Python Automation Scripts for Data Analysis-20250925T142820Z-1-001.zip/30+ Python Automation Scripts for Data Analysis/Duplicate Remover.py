import pandas as pd

def remove_duplicates(df):
    """
    Removes duplicate rows from a DataFrame.

    Args:
        df (pd.DataFrame): Input DataFrame.

    Returns:
        pd.DataFrame: DataFrame with duplicates removed.
    """
    return df.drop_duplicates()

# Example usage
if __name__ == "__main__":
    data = {'A': [1, 2, 2, 4, 5], 'B': [10, 20, 20, 40, 50]}
    df = pd.DataFrame(data)
    print("Before Removing Duplicates:\n", df)

    df = remove_duplicates(df)
    print("\nAfter Removing Duplicates:\n", df)
