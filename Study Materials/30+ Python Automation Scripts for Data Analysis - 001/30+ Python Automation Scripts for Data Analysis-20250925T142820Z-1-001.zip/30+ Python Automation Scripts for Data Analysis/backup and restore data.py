import shutil
import os

def backup_data(source_folder, backup_folder):
    """
    Backs up data by copying files to a backup folder.

    Args:
        source_folder (str): The folder containing data.
        backup_folder (str): The folder where backup should be stored.

    Returns:
        None
    """
    os.makedirs(backup_folder, exist_ok=True)
    for file in os.listdir(source_folder):
        shutil.copy(os.path.join(source_folder, file), os.path.join(backup_folder, file))

# Example usage
if __name__ == "__main__":
    backup_data("data_folder", "backup_folder")
