import pandas as pd
from sklearn.preprocessing import StandardScaler

def standardize_columns(df, columns):
    """
    Standardizes numerical columns.

    Args:
        df (pd.DataFrame): Input DataFrame.
        columns (list): List of column names to standardize.

    Returns:
        pd.DataFrame: DataFrame with standardized columns.
    """
    scaler = StandardScaler()
    df[columns] = scaler.fit_transform(df[columns])
    return df

# Example usage
if __name__ == "__main__":
    data = {'A': [10, 20, 30, 40, 50], 'B': [5, 15, 25, 35, 45]}
    df = pd.DataFrame(data)
    print("Before Standardization:\n", df)

    df = standardize_columns(df, ['A', 'B'])
    print("\nAfter Standardization:\n", df)
