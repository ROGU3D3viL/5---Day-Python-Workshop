import imaplib
import email

def extract_email_data(email_user, email_pass, mailbox="INBOX"):
    """
    Extracts email data from a specified mailbox.

    Args:
        email_user (str): Email username.
        email_pass (str): Email password.
        mailbox (str): Email folder to fetch data from.

    Returns:
        list: List of email subjects.
    """
    mail = imaplib.IMAP4_SSL("imap.gmail.com")
    mail.login(email_user, email_pass)
    mail.select(mailbox)
    
    _, data = mail.search(None, "ALL")
    email_ids = data[0].split()
    subjects = []
    
    for e_id in email_ids:
        _, msg_data = mail.fetch(e_id, "(RFC822)")
        raw_email = msg_data[0][1]
        msg = email.message_from_bytes(raw_email)
        subjects.append(msg["Subject"])
    
    mail.logout()
    return subjects

# Example usage
if __name__ == "__main__":
    subjects = extract_email_data("your-email@gmail.com", "your-password")
    print(subjects)
