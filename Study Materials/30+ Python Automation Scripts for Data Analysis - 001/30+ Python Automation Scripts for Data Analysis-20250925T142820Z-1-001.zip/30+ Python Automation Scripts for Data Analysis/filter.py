import pandas as pd

def filter_data(df, column, condition):
    """
    Filters data based on a condition.

    Args:
        df (pd.DataFrame): Input DataFrame.
        column (str): Column name to filter.
        condition (function): Lambda function for condition.

    Returns:
        pd.DataFrame: Filtered DataFrame.
    """
    return df[df[column].apply(condition)]

# Example usage
if __name__ == "__main__":
    data = {"A": [10, 20, 30, 40, 50]}
    df = pd.DataFrame(data)
    filtered_df = filter_data(df, "A", lambda x: x > 25)
    print(filtered_df)
