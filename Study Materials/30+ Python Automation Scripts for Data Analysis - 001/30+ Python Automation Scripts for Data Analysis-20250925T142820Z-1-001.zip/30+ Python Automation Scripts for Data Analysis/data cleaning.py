import pandas as pd
from sklearn.preprocessing import StandardScaler

def clean_data(df):
    """
    Automates data cleaning steps: missing values, duplicates, and normalization.

    Args:
        df (pd.DataFrame): Input DataFrame.

    Returns:
        pd.DataFrame: Cleaned DataFrame.
    """
    df.drop_duplicates(inplace=True)  # Remove duplicates
    df.fillna(df.mean(), inplace=True)  # Fill missing values with mean
    numerical_cols = df.select_dtypes(include=["number"]).columns  # Get numeric columns
    scaler = StandardScaler()
    df[numerical_cols] = scaler.fit_transform(df[numerical_cols])  # Normalize numerical data
    return df

# Example usage
if __name__ == "__main__":
    data = {"A": [1, 2, None, 4, 5], "B": [10, None, 30, 40, 50]}
    df = pd.DataFrame(data)
    print("Before Cleaning:\n", df)

    df = clean_data(df)
    print("\nAfter Cleaning:\n", df)
