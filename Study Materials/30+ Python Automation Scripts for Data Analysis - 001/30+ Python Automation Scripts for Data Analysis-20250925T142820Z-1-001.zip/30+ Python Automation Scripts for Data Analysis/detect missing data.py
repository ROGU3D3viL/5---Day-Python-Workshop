import pandas as pd

def missing_data_percentage(df):
    """
    Detects the percentage of missing data per column.

    Args:
        df (pd.DataFrame): Input DataFrame.

    Returns:
        pd.Series: Percentage of missing values per column.
    """
    return df.isnull().mean() * 100

# Example usage
if __name__ == "__main__":
    data = {"A": [1, 2, None, 4], "B": [None, 2, 3, 4]}
    df = pd.DataFrame(data)
    print(missing_data_percentage(df))
