import pandas as pd

def generate_pivot_table(df, index, values, aggfunc="sum"):
    """
    Creates a pivot table.

    Args:
        df (pd.DataFrame): Input DataFrame.
        index (str): Index column.
        values (str): Values column.
        aggfunc (str): Aggregation function ('sum', 'mean', etc.).

    Returns:
        pd.DataFrame: Pivot table.
    """
    return df.pivot_table(index=index, values=values, aggfunc=aggfunc)

# Example usage
if __name__ == "__main__":
    data = {"Category": ["A", "B", "A", "B"], "Sales": [100, 200, 150, 250]}
    df = pd.DataFrame(data)
    print(generate_pivot_table(df, "Category", "Sales"))
