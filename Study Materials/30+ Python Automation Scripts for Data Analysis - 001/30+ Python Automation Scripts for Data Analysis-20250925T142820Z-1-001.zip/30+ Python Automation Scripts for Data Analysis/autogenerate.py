import pandas as pd

def generate_data_summary(df):
    """
    Generates a summary of a dataset.

    Args:
        df (pd.DataFrame): Input DataFrame.

    Returns:
        pd.DataFrame: Summary statistics.
    """
    return df.describe()

# Example usage
if __name__ == "__main__":
    data = {"A": [10, 20, 30, 40, 50], "B": [5, 15, 25, 35, 45]}
    df = pd.DataFrame(data)
    print(generate_data_summary(df))
