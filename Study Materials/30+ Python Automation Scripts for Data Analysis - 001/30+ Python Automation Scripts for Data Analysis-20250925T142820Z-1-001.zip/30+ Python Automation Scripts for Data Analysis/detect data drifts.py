import pandas as pd

def detect_data_drift(df_old, df_new):
    """
    Detects data drift by comparing statistics of old and new datasets.

    Args:
        df_old (pd.DataFrame): Original dataset.
        df_new (pd.DataFrame): New dataset.

    Returns:
        pd.DataFrame: Differences in mean and std deviation.
    """
    drift_df = pd.DataFrame({
        "old_mean": df_old.mean(),
        "new_mean": df_new.mean(),
        "old_std": df_old.std(),
        "new_std": df_new.std()
    })
    drift_df["mean_diff"] = abs(drift_df["old_mean"] - drift_df["new_mean"])
    drift_df["std_diff"] = abs(drift_df["old_std"] - drift_df["new_std"])
    return drift_df

# Example usage
if __name__ == "__main__":
    df1 = pd.DataFrame({"A": [10, 12, 14], "B": [100, 120, 140]})
    df2 = pd.DataFrame({"A": [15, 18, 20], "B": [110, 130, 160]})
    print(detect_data_drift(df1, df2))
