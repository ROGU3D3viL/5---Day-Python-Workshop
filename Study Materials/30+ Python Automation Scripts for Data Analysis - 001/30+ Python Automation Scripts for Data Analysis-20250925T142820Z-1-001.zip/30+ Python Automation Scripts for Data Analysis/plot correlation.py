import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

def plot_correlation_heatmap(df):
    """
    Plots a correlation heatmap.

    Args:
        df (pd.DataFrame): Input DataFrame.

    Returns:
        None
    """
    plt.figure(figsize=(10, 8))
    sns.heatmap(df.corr(), annot=True, cmap="coolwarm")
    plt.show()

# Example usage
if __name__ == "__main__":
    data = {'A': [1, 2, 3, 4], 'B': [5, 6, 7, 8], 'C': [9, 10, 11, 12]}
    df = pd.DataFrame(data)
    plot_correlation_heatmap(df)
