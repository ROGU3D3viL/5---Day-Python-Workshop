import pdfplumber

def extract_pdf_tables(file_path):
    """
    Extracts tables from a PDF file.

    Args:
        file_path (str): Path to PDF file.

    Returns:
        list: List of extracted tables.
    """
    with pdfplumber.open(file_path) as pdf:
        tables = [page.extract_table() for page in pdf.pages if page.extract_table()]
    return tables

# Example usage
if __name__ == "__main__":
    tables = extract_pdf_tables("sample.pdf")
    print(tables)
