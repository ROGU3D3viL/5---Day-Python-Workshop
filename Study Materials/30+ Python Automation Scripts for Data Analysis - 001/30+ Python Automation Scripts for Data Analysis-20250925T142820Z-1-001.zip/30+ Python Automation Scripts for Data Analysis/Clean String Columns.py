import pandas as pd
import re

def clean_strings(df, columns):
    """
    Cleans string columns by removing special characters and converting to lowercase.

    Args:
        df (pd.DataFrame): Input DataFrame.
        columns (list): List of column names to clean.

    Returns:
        pd.DataFrame: Cleaned DataFrame.
    """
    for col in columns:
        df[col] = df[col].astype(str).str.lower().str.replace(r'[^a-zA-Z0-9\\s]', '', regex=True)
    return df

# Example usage
if __name__ == "__main__":
    data = {'Name': ['Alice!', 'BoB##', 'Char_lie', 'Dav!d']}
    df = pd.DataFrame(data)
    print("Before Cleaning:\n", df)

    df = clean_strings(df, ['Name'])
    print("\nAfter Cleaning:\n", df)
