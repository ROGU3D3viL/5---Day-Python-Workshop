import pandas as pd

def detect_outliers(df, column):
    """
    Detects and removes outliers using the IQR method.

    Args:
        df (pd.DataFrame): Input DataFrame.
        column (str): Column name for outlier detection.

    Returns:
        pd.DataFrame: DataFrame without outliers.
    """
    Q1 = df[column].quantile(0.25)
    Q3 = df[column].quantile(0.75)
    IQR = Q3 - Q1
    df = df[(df[column] >= (Q1 - 1.5 * IQR)) & (df[column] <= (Q3 + 1.5 * IQR))]
    return df

# Example usage
if __name__ == "__main__":
    data = {'A': [10, 12, 14, 100, 16, 18]}
    df = pd.DataFrame(data)
    print("Before Removing Outliers:\n", df)

    df = detect_outliers(df, 'A')
    print("\nAfter Removing Outliers:\n", df)
