import pandas as pd
import requests
from bs4 import BeautifulSoup

def scrape_table_from_web(url):
    """
    Scrapes table data from a webpage.

    Args:
        url (str): Web page URL.

    Returns:
        pd.DataFrame: Extracted table as DataFrame.
    """
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')
    table = soup.find('table')
    return pd.read_html(str(table))[0] if table else None

# Example usage
if __name__ == "__main__":
    url = "https://example.com/table"
    df = scrape_table_from_web(url)
    print(df)
