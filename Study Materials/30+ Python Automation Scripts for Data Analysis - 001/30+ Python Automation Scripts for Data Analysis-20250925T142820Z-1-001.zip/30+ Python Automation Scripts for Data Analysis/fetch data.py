import requests

def fetch_api_data(url):
    """
    Fetches data from an API.

    Args:
        url (str): API endpoint URL.

    Returns:
        dict: JSON response from API.
    """
    response = requests.get(url)
    return response.json() if response.status_code == 200 else None

# Example usage
if __name__ == "__main__":
    url = "https://api.publicapis.org/entries"
    data = fetch_api_data(url)
    print(data)
