import os
import shutil

def move_files(source_folder, dest_folder, file_extension):
    """
    Moves files based on their extension.

    Args:
        source_folder (str): Folder where files are located.
        dest_folder (str): Destination folder.
        file_extension (str): File extension to filter (e.g., '.csv').

    Returns:
        None
    """
    os.makedirs(dest_folder, exist_ok=True)
    for file in os.listdir(source_folder):
        if file.endswith(file_extension):
            shutil.move(os.path.join(source_folder, file), os.path.join(dest_folder, file))

# Example usage
if __name__ == "__main__":
    move_files("source_folder", "destination_folder", ".csv")
