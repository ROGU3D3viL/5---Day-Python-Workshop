import pandas as pd

def format_dates(df, column, format='%Y-%m-%d'):
    """
    Converts date column into a standard format.

    Args:
        df (pd.DataFrame): Input DataFrame.
        column (str): Column name containing date values.
        format (str): Desired date format.

    Returns:
        pd.DataFrame: DataFrame with formatted date column.
    """
    df[column] = pd.to_datetime(df[column], errors='coerce').dt.strftime(format)
    return df

# Example usage
if __name__ == "__main__":
    data = {'Date': ['2023-03-15', '15-04-2022', 'March 10, 2021']}
    df = pd.DataFrame(data)
    print("Before Formatting:\n", df)

    df = format_dates(df, 'Date')
    print("\nAfter Formatting:\n", df)
