import dash
from dash import dcc, html
import pandas as pd
import plotly.express as px
import time
import threading
from flask import Flask

# Create Flask app
server = Flask(__name__)

# Generate initial data
def generate_data():
    df = pd.DataFrame({"Time": [time.ctime()], "Value": [100]})
    df.to_csv("live_data.csv", index=False)

# Function to update live data
def update_live_data():
    while True:
        df = pd.read_csv("live_data.csv")
        new_row = {"Time": time.ctime(), "Value": df["Value"].iloc[-1] + 10}
        df = df.append(new_row, ignore_index=True)
        df.to_csv("live_data.csv", index=False)
        time.sleep(5)  # Update every 5 seconds

# Start data update in the background
threading.Thread(target=update_live_data, daemon=True).start()

# Create Dash app for real-time visualization
app = dash.Dash(__name__, server=server)
app.layout = html.Div([
    html.H1("Live Data Monitoring"),
    dcc.Interval(id="interval", interval=5000, n_intervals=0),
    dcc.Graph(id="live-graph")
])

# Update graph dynamically
@app.callback(
    dash.dependencies.Output("live-graph", "figure"),
    [dash.dependencies.Input("interval", "n_intervals")]
)
def update_graph(n):
    df = pd.read_csv("live_data.csv")
    fig = px.line(df, x="Time", y="Value", title="Live Data Trends")
    return fig

if __name__ == "__main__":
    app.run_server(debug=True)
