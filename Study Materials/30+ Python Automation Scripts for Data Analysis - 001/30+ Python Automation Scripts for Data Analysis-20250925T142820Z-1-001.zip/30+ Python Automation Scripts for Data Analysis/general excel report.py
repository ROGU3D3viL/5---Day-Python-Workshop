import pandas as pd

def generate_report(df, file_path="report.xlsx"):
    """
    Generates an Excel report from a DataFrame.

    Args:
        df (pd.DataFrame): Input DataFrame.
        file_path (str): Output file path.

    Returns:
        None
    """
    df.to_excel(file_path, index=False)
    print(f"Report saved to {file_path}")

# Example usage
if __name__ == "__main__":
    data = {'A': [1, 2, 3], 'B': [4, 5, 6]}
    df = pd.DataFrame(data)
    generate_report(df)
