import pandas as pd
import schedule
import time

def process_data():
    """
    Simulates data processing task.
    """
    data = {"Timestamp": [time.ctime()], "Value": [100]}  # Sample Data
    df = pd.DataFrame(data)
    df.to_csv("scheduled_data.csv", mode="a", header=False, index=False)
    print(f"Data processed and saved at {time.ctime()}")

# Schedule the task to run every minute
schedule.every(1).minutes.do(process_data)

if __name__ == "__main__":
    print("Scheduler started. Processing data every minute...")
    while True:
        schedule.run_pending()
        time.sleep(1)
