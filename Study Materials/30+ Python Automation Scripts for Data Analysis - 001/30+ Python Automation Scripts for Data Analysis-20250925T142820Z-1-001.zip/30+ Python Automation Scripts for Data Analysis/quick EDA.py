import pandas as pd

def quick_eda(df):
    """
    Generates a quick summary of a DataFrame.

    Args:
        df (pd.DataFrame): Input DataFrame.

    Returns:
        None
    """
    print("Shape:", df.shape)
    print("\nInfo:")
    print(df.info())
    print("\nDescription:")
    print(df.describe())

# Example usage
if __name__ == "__main__":
    data = {'A': [1, 2, 3, 4], 'B': [5, 6, 7, 8]}
    df = pd.DataFrame(data)
    quick_eda(df)
