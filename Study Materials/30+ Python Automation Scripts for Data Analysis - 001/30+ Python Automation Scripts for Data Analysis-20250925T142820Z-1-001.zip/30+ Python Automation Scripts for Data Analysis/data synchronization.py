import shutil
import os

def sync_folders(source_folder, dest_folder):
    """
    Synchronizes files between two folders.

    Args:
        source_folder (str): Source folder.
        dest_folder (str): Destination folder.

    Returns:
        None
    """
    os.makedirs(dest_folder, exist_ok=True)
    for file in os.listdir(source_folder):
        shutil.copy2(os.path.join(source_folder, file), os.path.join(dest_folder, file))

# Example usage
if __name__ == "__main__":
    sync_folders("source_folder", "sync_folder")
