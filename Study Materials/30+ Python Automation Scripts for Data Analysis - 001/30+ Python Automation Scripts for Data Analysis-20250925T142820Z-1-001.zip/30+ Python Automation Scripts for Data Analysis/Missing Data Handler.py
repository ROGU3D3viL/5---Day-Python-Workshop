import pandas as pd

def handle_missing_values(df, method='mean'):
    """
    Handles missing values in a DataFrame using mean, median, or mode.

    Args:
        df (pd.DataFrame): Input DataFrame.
        method (str): Method to fill missing values ('mean', 'median', 'mode').

    Returns:
        pd.DataFrame: DataFrame with missing values handled.
    """
    if method == 'mean':
        df.fillna(df.mean(), inplace=True)
    elif method == 'median':
        df.fillna(df.median(), inplace=True)
    elif method == 'mode':
        df.fillna(df.mode().iloc[0], inplace=True)
    return df

# Example usage
if __name__ == "__main__":
    data = {'A': [1, 2, None, 4, 5], 'B': [None, 2, 3, None, 5]}
    df = pd.DataFrame(data)
    print("Before Handling Missing Values:\n", df)

    df = handle_missing_values(df, method='mean')
    print("\nAfter Handling Missing Values:\n", df)
