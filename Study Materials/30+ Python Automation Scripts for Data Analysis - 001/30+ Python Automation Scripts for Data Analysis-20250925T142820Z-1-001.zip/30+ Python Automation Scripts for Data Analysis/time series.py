import pandas as pd
import matplotlib.pyplot as plt

def plot_time_series_trends(df, date_column, value_column):
    """
    Plots trends for time-series data.

    Args:
        df (pd.DataFrame): Input DataFrame.
        date_column (str): Date column.
        value_column (str): Value column.

    Returns:
        None
    """
    df[date_column] = pd.to_datetime(df[date_column])
    df.set_index(date_column, inplace=True)
    df[value_column].plot(figsize=(10, 5), title="Time Series Trend", grid=True)
    plt.show()

# Example usage
if __name__ == "__main__":
    data = {"Date": ["2023-01-01", "2023-02-01", "2023-03-01"], "Sales": [100, 150, 200]}
    df = pd.DataFrame(data)
    plot_time_series_trends(df, "Date", "Sales")
