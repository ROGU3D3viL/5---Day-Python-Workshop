This tool is an Open Source AES Standard encrytion tool, Always make sure to 
backup the encryption key if not the files cannot be reverted back....!!!
