# Script Title
<!--Remove the below lines and add yours -->
A small python program that converts binary and decimal

### Prerequisites
<!--Remove the below lines and add yours -->
- Python 3

### How to run the script
<!--Remove the below lines and add yours -->
> python decimal_to_binary.py

