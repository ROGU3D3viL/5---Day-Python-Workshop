# Image-Watermark

## Description

This Project will take an image and add desired watermark to it.

## About this Project

This project uses PIL module and OS module to add the watermark. PIL, the Python Imaging Library, is an open source libary that enables the users to add, manipulate and save different file formats.
