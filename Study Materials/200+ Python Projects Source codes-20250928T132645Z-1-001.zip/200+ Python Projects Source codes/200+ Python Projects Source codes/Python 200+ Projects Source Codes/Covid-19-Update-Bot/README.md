# Covid-19-Update-Bot
Covid-19 Update Bot that will Notifiy about the current covid-19 Cases, Deaths, Recovered






# Dependencies:
*json*

```
pip install json
```
*win 10 toast*

```
pip install win10toast
```

*Initially it shows the cases worldwide it will notify after every hour*

*If you want to see cases for india or any other country then change this line in the code*
```
r = requests.get('https://coronavirus-19-api.herokuapp.com/countries/india')
```





