## Merge_pdfs

A simple python script which when executed merges two pdfs

## Prerequisites

Run - "pip install PyPDF2"

## How to run the script

It can be executed by running "python merge_pdfs.py"

