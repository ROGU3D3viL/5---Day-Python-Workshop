What is the use:
Given a username if the Instagram account is public or the posts are accessible to the operator, will auto-like all the posts on behalf and exit.
Instructions to use:
1.	Once we run the program, web driver will start the default browser under automated software (here we use chrome).

2.	Then it will ask for the username and password for the account that will be used to give the likes.

3.	Then it will automatically go to the search bar, and ask for the username of the person whose post you want to like.

4.	After pressing enter, it will automatically open the Instagram account of the user and keep liking every available uploaded post.

5.	Once done, it will close the posts itself.

Side note:
If you are using some other web browser, replace ‘chrome’ by the name of that browser
Modules and tools used:
Selenium, getpass and time

