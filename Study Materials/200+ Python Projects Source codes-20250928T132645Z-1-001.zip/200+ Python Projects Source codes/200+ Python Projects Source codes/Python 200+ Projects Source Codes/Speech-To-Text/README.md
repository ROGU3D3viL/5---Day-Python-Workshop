# Speech-To-Text
A program that can convert Speech into Text using python


# Dependencies:

*pyttsx3*
```python

pip install pyttsx3
```
*pyaudio*
```python
pip install pyaudio
```
*SpeechRecognition*
```
pip install SpeechRecognition
```
# Run:
*The text Will be saved in output.txt file*

```
python speech-to-text.py
```

