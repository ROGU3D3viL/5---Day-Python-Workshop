# Script Title
<!--Remove the below lines and add yours -->
A small python program that creates a calculator app

### Prerequisites
<!--Remove the below lines and add yours -->
Python 3

### How to run the script
<!--Remove the below lines and add yours -->
> python calculator.py




