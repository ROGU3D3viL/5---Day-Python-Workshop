# PageSpeed

This script generates the PageSpeed API results for a website.

## Packages required:

- requests
- json

## Instructions

To use the package, just check the test.py file.

## Output

Depending upon the use of the script, it can generate a json file for the pagespeed results, and 
it also returns the regular response object.

