

## Email GUI Functionalities : 🚀

- **To send email the less security option of sender's email must be turned on.**
- Enter all the details like sender's email, password, Recipient's Email and message.
- The script logs into the gmail account and then sends the message.

## Select Stocks by volume Increase Instructions: 👨🏻‍💻

### Step 1:

    Open Termnial 💻

### Step 2:

    Locate to the directory where python file is located 📂

### Step 3:

    Run the command: python script.py/python3 script.py 🧐

### Step 4:

    Sit back and Relax. Let the Script do the Job. ☕

### Requirements

- smtplib
- tkinter


