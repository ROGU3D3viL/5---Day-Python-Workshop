<h1 align="center">URL Shortner</h1>

#### It records the computer screen. 

---------------------------------------------------------------------

## Modules Used
- time
- PIL
- numpy
- cv2
## How it works
- While Running the script it captures the screen frames.

- Then it returns the screen record with realtime changes.
