# Fetch open port
<!--Remove the below lines and add yours -->
This script finds open port for web address.

### Prerequisites
<!--Remove the below lines and add yours -->
No need for additional installations.

### How to run the script
```

2. Run following command
```
    python3 fetch_open_port.py
```

3. Once script is running, you can write any website you want, and it will print all open ports in range 50-500.




