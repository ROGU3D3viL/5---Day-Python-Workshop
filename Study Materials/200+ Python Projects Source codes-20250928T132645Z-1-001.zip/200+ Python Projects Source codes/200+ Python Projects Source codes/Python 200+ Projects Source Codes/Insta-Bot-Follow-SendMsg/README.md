# instabot.py
## What is the use:
Given a username if the Instagram account is public , will auto-follow and send msg.
Instructions to use:
1.	Once we run the program, web driver will start the default browser under automated software (here we use chrome).

2.      Then it will ask for the user id of users whom you want to follow and send msg.

3.	Then it will ask for the username and password for the account that will be used to follow and send msg.

4.	Then it will automatically go to the  username of the person whom  you want to follow and send msg.

4.	After pressing enter, it will automatically open the Instagram account of the user and  follow and send msg .

5.	Once done, it will Show the Msg.

## Note:
If you are using some other web browser, replace ‘chrome’ by the name of that browser
Modules and tools used:
Selenium, getpass and time


