import time 
import webbrowser


for i in range(3):
	time.sleep(10)
	webbrowser.open("https://www.youtube.com/watch?v=7wtfhZwyrcc")
