

## Dependencies:

*Google Translate*
```python

pip install googletrans
```
*pyttsx3*
```python

pip install pyttsx3
```
*pyaudio*
```python
pip install pyaudio
```
*speech recongnition*
```python
pip install SpeechRecognition
```

