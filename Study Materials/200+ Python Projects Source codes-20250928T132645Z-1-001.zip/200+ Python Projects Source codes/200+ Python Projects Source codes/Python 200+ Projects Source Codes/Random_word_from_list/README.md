# Random word from list

This is a useful program that chooses a random word from a given list.

#### How to run script
``` bash
python Random_word_from_list.py
```
Make sure you have a file in the same directory you wish to choose a random word from.
