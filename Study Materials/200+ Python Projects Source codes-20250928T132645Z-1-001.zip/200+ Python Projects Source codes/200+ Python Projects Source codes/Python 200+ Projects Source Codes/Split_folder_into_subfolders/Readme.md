## Split folder into subfolders

### Execute
python <input_folder_name> <files_count>
