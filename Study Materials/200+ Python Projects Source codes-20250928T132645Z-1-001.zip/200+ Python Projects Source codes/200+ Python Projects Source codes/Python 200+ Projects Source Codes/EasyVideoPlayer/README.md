# EasyVideoPlayer
  EasyVideoPlayer script is a video player based on the terminal. It can find the video in a pc, change its working directory and play the video file. 

### Prerequisites
  cv2, os, pathlib and ffpyplayer.player libraries are needed to run this script, all of which can be installed using "pip3 install 'library name'".

### How to run the script
  'cd' to the directory that contains the script and type "python3 EasyVideoPlayer.py". When you are done with the video, use "keyboard interrupt" (Ctrl + C) to exit the player.
