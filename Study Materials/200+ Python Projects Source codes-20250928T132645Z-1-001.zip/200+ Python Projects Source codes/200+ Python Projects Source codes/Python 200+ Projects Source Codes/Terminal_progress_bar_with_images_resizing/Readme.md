# Terminal Progress bar with image Resizing

Here I just take example of image resizing for displaying progress bar.
when we convert lots of images at time we can use progress bar to show how many images are resized.

### For this purpose I am using tqdm librabry
` pip install tqdm `

This Library is for showing progress bar

### For Resizing images
` pip install Pillow `
