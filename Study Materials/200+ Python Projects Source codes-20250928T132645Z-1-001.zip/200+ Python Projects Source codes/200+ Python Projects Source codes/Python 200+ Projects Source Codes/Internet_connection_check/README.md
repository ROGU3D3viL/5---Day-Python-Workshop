# Internet Connection Check
<!--Remove the below lines and add yours -->
A small python script to check internet connectivity.

### Prerequisites
<!--Remove the below lines and add yours -->
Python3

### How to run the script
<!--Remove the below lines and add yours -->
> python3 internet_connection_check.py



