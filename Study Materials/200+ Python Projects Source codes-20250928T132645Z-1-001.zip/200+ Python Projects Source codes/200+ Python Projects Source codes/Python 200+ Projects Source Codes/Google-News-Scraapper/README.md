### Google News Scrapper

A python Automation script that helps to scrape the google news articles. The key feature of this script is that user can able to scrape the as many number of articles by giving the number of articles count. This script will generate the excel file of all the scraped articles with links with their respective titles.

### Setup
1. Create the Virtual Environment
2. Install all the required packages by using `pip3 install -r requirements.txt`

### Running the Script
`python3 app.py`