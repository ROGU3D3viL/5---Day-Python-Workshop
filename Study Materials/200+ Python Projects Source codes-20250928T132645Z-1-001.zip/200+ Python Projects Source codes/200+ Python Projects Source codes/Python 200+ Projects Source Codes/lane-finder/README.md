# lane-finder
 Python code for finding lanes
 
 An attempt to build the Tesla's autopilot lane finder Algorithm

 To run, change directory to project directory and run the command 'python finding_lanes.py'
 
 HAPPY HACKING!
