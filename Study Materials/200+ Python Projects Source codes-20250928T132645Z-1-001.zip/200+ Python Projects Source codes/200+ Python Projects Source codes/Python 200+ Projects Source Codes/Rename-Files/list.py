import os

x = os.listdir("/Users/User/Desktop/uni/change file names/workedOn")
print(x)